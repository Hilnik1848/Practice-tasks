package com.example.travenor;


import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;


import com.example.travenor.Models.ScheduleItem;
import com.example.travenor.Models.DataBinding;
import com.example.travenor.Models.LoginRequest;
import com.example.travenor.Models.ProfileUpdate;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Objects;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class SupabaseClient {

    public static String DOMAIN_NAME = "https://mmbdesfnabtcbpjwcwde.supabase.co/";
    public static String REST_PATH = "rest/v1/";
    public static String AUTH_PATH = "auth/v1/";
    public static String API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1tYmRlc2ZuYWJ0Y2Jwandjd2RlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg5NTg4MDMsImV4cCI6MjA2NDUzNDgwM30.zU9xsd7HMVuLi6OkiKTaB723ek2YNomMgrqnKKvSvQk";

    OkHttpClient client = new OkHttpClient();
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    private static final MediaType JSON = MediaType.get("application/json");
    public void registr(LoginRequest loginRequest, final SBC_Callback callback){
        MediaType mediaType = MediaType.parse("application/json");
        Gson gson = new Gson();
        String json = gson.toJson(loginRequest);
        RequestBody body = RequestBody.create(mediaType, json);

        Request request = new Request.Builder()
                .url(DOMAIN_NAME + AUTH_PATH + "signup")
                .method("POST", body)
                .addHeader("apikey", API_KEY)
                .addHeader("Content-Type", "application/json")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    String responseBody = response.body().string();
                    callback.onResponse(responseBody);
                } else {
                    callback.onFailure(new IOException("Ошибка сервера: " + response));
                }
            }
        });
    }

    public void updateProfile(ProfileUpdate profile, final SBC_Callback callback) {
        MediaType mediaType = MediaType.parse("application/json");
        Gson gson = new Gson();
        String json = gson.toJson(profile);
        RequestBody body = RequestBody.create(mediaType, json);

        Request request = new Request.Builder()
                .url(DOMAIN_NAME + REST_PATH + "profiles?id=eq." + DataBinding.getUuidUser())
                .method("PATCH", body)
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", Objects.requireNonNull(DataBinding.getBearerToken()))
                .addHeader("Content-Type", "application/json")
                .addHeader("Prefer", "return=minimal")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    String responseBody = response.body().string();
                    callback.onResponse(responseBody);
                } else {
                    callback.onFailure(new IOException("Ошибка сервера: " + response.code()));
                }
            }
        });
    }


    public void login(LoginRequest loginRequest, SBC_Callback callback) {
        MediaType mediaType = MediaType.get("application/json");
        String json = new Gson().toJson(loginRequest);
        RequestBody body = RequestBody.create(mediaType, json);

        Request request = new Request.Builder()
                .url(DOMAIN_NAME + AUTH_PATH + "token?grant_type=password")
                .post(body)
                .addHeader("apikey", API_KEY)
                .addHeader("Content-Type", "application/json")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    String body = response.body().string();
                    callback.onResponse(body);
                } else {
                    callback.onFailure(new IOException("Ошибка сервера: " + response.code()));
                }
            }
        });
    }

    public void sendRecoveryEmail(String email, final SBC_Callback callback) {
        JSONObject payload = new JSONObject();
        try {
            payload.put("email", email);
        } catch (Exception e) {
            callback.onFailure(new IOException("Ошибка формирования данных: " + e.getMessage()));
            return;
        }

        RequestBody body = RequestBody.create(JSON, payload.toString());
        Request request = new Request.Builder()
                .url(DOMAIN_NAME + AUTH_PATH + "recover")
                .post(body)
                .addHeader("apikey", API_KEY)
                .addHeader("Content-Type", "application/json")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    callback.onResponse("Код отправлен на ваш email");
                } else {
                    String errorBody = response.body() != null ? response.body().string() : "Неизвестная ошибка";
                    callback.onFailure(new IOException("Ошибка: " + errorBody));
                }
            }
        });
    }

    public void verifyOtp(String email, String token, final SBC_Callback callback) {
        JSONObject payload = new JSONObject();
        try {
            payload.put("email", email);
            payload.put("token", token);
            payload.put("type", "recovery");
        } catch (Exception e) {
            callback.onFailure(new IOException("Ошибка формирования данных: " + e.getMessage()));
            return;
        }

        RequestBody body = RequestBody.create(JSON, payload.toString());
        Request request = new Request.Builder()
                .url(DOMAIN_NAME + AUTH_PATH + "verify")
                .post(body)
                .addHeader("apikey", API_KEY)
                .addHeader("Content-Type", "application/json")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        assert response.body() != null;
                        String responseBody = response.body().string();
                        JSONObject json = new JSONObject(responseBody);
                        String accessToken = json.getString("access_token");

                        DataBinding.saveBearerToken(accessToken);
                        callback.onResponse(accessToken);
                    } catch (Exception e) {
                        callback.onFailure(new IOException("Ошибка обработки ответа: " + e.getMessage()));
                    }
                } else {
                    String errorBody = response.body() != null ? response.body().string() : "Неизвестная ошибка";
                    try {
                        JSONObject errorJson = new JSONObject(errorBody);
                        String errorCode = errorJson.optString("error_code", "");
                        String errorMsg = errorJson.optString("msg", "Ошибка сервера");

                        if ("otp_expired".equals(errorCode)) {
                            callback.onFailure(new IOException("OTP истёк"));
                        } else if ("invalid_token".equals(errorCode)) {
                            callback.onFailure(new IOException("Неверный токен"));
                        } else {
                            callback.onFailure(new IOException("Ошибка: " + errorMsg));
                        }
                    } catch (Exception e) {
                        callback.onFailure(new IOException("Ошибка сервера: " + errorBody));
                    }
                }
            }
        });
    }

    public void updatePassword(String newPassword, final SBC_Callback callback) {
        String accessToken = DataBinding.getBearerToken();
        if (accessToken == null) {
            callback.onFailure(new IOException("Требуется авторизация"));
            return;
        }

        JSONObject payload = new JSONObject();
        try {
            payload.put("password", newPassword);
        } catch (Exception e) {
            callback.onFailure(new IOException("Ошибка формирования данных: " + e.getMessage()));
            return;
        }

        RequestBody body = RequestBody.create(JSON, payload.toString());
        Request request = new Request.Builder()
                .url(DOMAIN_NAME + AUTH_PATH + "user")
                .put(body)
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", "Bearer " + accessToken)
                .addHeader("Content-Type", "application/json")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    callback.onResponse("Пароль успешно изменён");
                } else {
                    String errorBody = response.body() != null ? response.body().string() : "Неизвестная ошибка";
                    callback.onFailure(new IOException("Ошибка при смене пароля: " + errorBody));
                }
            }
        });
    }



    public void fetchUserProfile(SBC_Callback callback) {
        String userId = DataBinding.getUuidUser();
        if (userId == null || userId.isEmpty()) {
            callback.onFailure(new IOException("Пользователь не авторизован"));
            return;
        }

        String url = DOMAIN_NAME + REST_PATH + "profiles?id=eq." + userId;

        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", DataBinding.getBearerToken())
                .addHeader("Content-Type", "application/json")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    String body = response.body().string();
                    callback.onResponse(body);
                } else {
                    String errorBody = response.body() != null ? response.body().string() : "Неизвестная ошибка";
                    callback.onFailure(new IOException("Ошибка сервера: " + response.code() + ", " + errorBody));
                }
            }
        });
    }
    public void updateProfile(String userId, ProfileUpdate profileUpdate, SBC_Callback callback) {
        MediaType JSON = MediaType.get("application/json; charset=utf-8");
        Gson gson = new Gson();
        String json = gson.toJson(profileUpdate);
        RequestBody body = RequestBody.create(JSON, json);

        Request request = new Request.Builder()
                .url(DOMAIN_NAME + REST_PATH + "profiles?id=eq." + userId)
                .patch(body)
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", DataBinding.getBearerToken())
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    callback.onResponse("OK");
                } else {
                    callback.onFailure(new IOException("Ошибка сервера"));
                }
            }
        });
    }

    public void changePassword(String newPassword, SBC_Callback callback) {
        String url = DOMAIN_NAME + "/auth/v1/user";

        MediaType JSON = MediaType.get("application/json; charset=utf-8");
        String json = "{ \"password\": \"" + newPassword + "\" }";

        RequestBody body = RequestBody.create(JSON, json);

        Request request = new Request.Builder()
                .url(url)
                .put(body)
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", DataBinding.getBearerToken())
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    callback.onResponse("OK");
                } else {
                    String errorBody = response.body() != null ? response.body().string() : "Неизвестная ошибка";
                    callback.onFailure(new IOException("Ошибка сервера: " + response.code() + "\n" + errorBody));
                }
            }
        });
    }


    public void changeEmail(Context context, String newEmail, SBC_Callback callback) {
        JSONObject jsonBody = new JSONObject();
        SessionManager sessionManager = new SessionManager(context);

        try {
            jsonBody.put("target_user_id", sessionManager.getUserId());
            jsonBody.put("new_email", newEmail);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        MediaType JSON = MediaType.get("application/json; charset=utf-8");
        RequestBody body = RequestBody.create(JSON, jsonBody.toString());

        Request request = new Request.Builder()
                .url(DOMAIN_NAME + REST_PATH + "rpc/change_user_email_verified")
                .post(body)
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", "Bearer " + sessionManager.getBearerToken())
                .addHeader("Content-Type", "application/json")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    callback.onResponse(response.body().string());
                } else {
                    callback.onFailure(new IOException("Ошибка сервера: " + response.code()));
                }
            }
        });
    }


    public void uploadAvatar(Uri uri, String fileName, SBC_Callback callback, Context context) {
        String realPath = RealPathUtil.getRealPath(context, uri);
        if (realPath == null) {
            callback.onFailure(new IOException("Не удалось получить путь файла"));
            return;
        }

        File file = new File(realPath);

        RequestBody requestBody = RequestBody.create(MediaType.parse("image/*"), file);

        MultipartBody body = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", fileName, requestBody)
                .build();

        String url = DOMAIN_NAME + "/storage/v1/object/avatars/" + fileName;

        Request request = new Request.Builder()
                .url(url)
                .put(body)
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", DataBinding.getBearerToken())
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    callback.onResponse(response.body().string());
                } else {
                    String errorBody = response.body() != null ? response.body().string() : "Empty response";
                    callback.onFailure(new IOException("Upload failed: " + response.code() + ", Body: " + errorBody));
                }
            }
        });
    }

    public void fetchHotels(final SBC_Callback callback) {
        String url = DOMAIN_NAME + REST_PATH + "Hotels?select=*";

        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", DataBinding.getBearerToken())
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    String responseBody = response.body().string();
                    callback.onResponse(responseBody);
                } else {
                    callback.onFailure(new IOException("Failed to fetch hotels"));
                }
            }
        });
    }

    public void fetchHotelDetails(String hotelId, final SBC_Callback callback) {
        String url = DOMAIN_NAME + REST_PATH + "Hotels?id=eq." + hotelId;

        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", DataBinding.getBearerToken())
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    String responseBody = response.body().string();
                    callback.onResponse(responseBody);
                } else {
                    callback.onFailure(new IOException("Failed to fetch hotel details"));
                }
            }
        });
    }

    public void toggleFavorite(String userId, String hotelId, SimpleCallback callback) {
        checkFavorite(userId, hotelId, new FavoriteCallback() {
            @Override
            public void onResult(boolean isFavorite) {
                if (isFavorite) {
                    removeFavorite(userId, hotelId, callback);
                } else {
                    addFavorite(userId, hotelId, callback);
                }
            }

            @Override
            public void onError(Exception e) {
                callback.onError(e);
            }
        });
    }


    public void checkFavorite(String userId, String hotelId, final FavoriteCallback callback) {
        String url = DOMAIN_NAME + REST_PATH + "favorites?user_id=eq." + userId + "&hotel_id=eq." + hotelId;
        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", DataBinding.getBearerToken())
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onError(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    String body = response.body().string();
                    boolean exists = !body.equals("[]");
                    callback.onResult(exists);
                } else {
                    callback.onError(new IOException("Ошибка проверки избранного"));
                }
            }
        });
    }

    public void addFavorite(String userId, String hotelId, final SimpleCallback callback) {
        String json = "{ \"user_id\": \"" + userId + "\", \"hotel_id\": \"" + hotelId + "\" }";
        MediaType JSON = MediaType.get("application/json; charset=utf-8");

        RequestBody body = RequestBody.create(JSON, json);

        String url = DOMAIN_NAME + REST_PATH + "favorites";

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", DataBinding.getBearerToken())
                .addHeader("Prefer", "return=minimal")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onError(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    callback.onSuccess();
                } else {
                    callback.onError(new IOException("Не удалось добавить в избранное"));
                }
            }
        });
    }

    public void removeFavorite(String userId, String hotelId, SimpleCallback callback) {
        String url = DOMAIN_NAME + REST_PATH + "favorites?user_id=eq." + userId + "&hotel_id=eq." + hotelId;

        Request request = new Request.Builder()
                .url(url)
                .delete()
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", DataBinding.getBearerToken())
                .addHeader("Prefer", "return=minimal")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                new Handler(Looper.getMainLooper()).post(() ->
                        callback.onError(e)
                );
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) {
                if (response.code() == 204) {
                    new Handler(Looper.getMainLooper()).post(() ->
                            callback.onSuccess()
                    );
                } else {
                    new Handler(Looper.getMainLooper()).post(() ->
                            callback.onError(new IOException("Не удалось удалить"))
                    );
                }
            }
        });
    }

    public void fetchFavoritesForUser(String userId, SBC_Callback callback) {
        String url = DOMAIN_NAME + REST_PATH + "favorites?user_id=eq." + userId + "&select=*,Hotels(*)";

        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", DataBinding.getBearerToken())
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    callback.onResponse(response.body().string());
                } else {
                    callback.onFailure(new IOException("Не удалось загрузить избранное"));
                }
            }
        });
    }


    public void fetchBookingsForUser(String userId, SBC_Callback callback) {
        Request request = new Request.Builder()
                .url(DOMAIN_NAME + "/rest/v1/bookings?select=*,hotel_room(*,Hotels(*))&user_id=eq." + userId)
                .get()
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", DataBinding.getBearerToken())
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    callback.onResponse(response.body().string());
                } else {
                    callback.onFailure(new IOException("Ошибка получения бронирования"));
                }
            }
        });
    }

    public void fetchUserChats(String userId, final SBC_Callback callback) {
        String url = DOMAIN_NAME + REST_PATH + "chats?user_id=eq." + userId +
                "&select=*,managers(*,profiles(*)),profiles!chats_user_id_fkey(*)";

        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", DataBinding.getBearerToken())
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    callback.onResponse(response.body().string());
                } else {
                    callback.onFailure(new IOException("Failed to fetch chats"));
                }
            }
        });
    }

    public void fetchManagerId(String userId, final SBC_Callback callback) {
        String url = DOMAIN_NAME + REST_PATH + "managers?user_id=eq." + userId + "&select=id";

        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", DataBinding.getBearerToken())
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    callback.onResponse(response.body().string());
                } else {
                    callback.onFailure(new IOException("Ошибка при получении manager_id"));
                }
            }

            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }
        });
    }
    public void fetchManagerChats(int managerId, final SBC_Callback callback) {
        String url = DOMAIN_NAME + REST_PATH + "chats?manager_id=eq." + managerId +
                "&select=*,user:profiles(*),manager:managers(*,profile:profiles(*))";

        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", DataBinding.getBearerToken())
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    callback.onResponse(response.body().string());
                } else {
                    callback.onFailure(new IOException("Ошибка при получении чатов"));
                }
            }

            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }
        });
    }

    public void checkIfManager(String userId, final SBC_Callback callback) {
        String url = DOMAIN_NAME + REST_PATH + "managers?user_id=eq." + userId;

        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", DataBinding.getBearerToken())
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    callback.onResponse(response.body().string());
                } else {
                    callback.onFailure(new IOException("Failed to check manager status"));
                }
            }
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                callback.onFailure(e);
            }
        });
    }

    public void get(@NonNull String url, @NonNull SBC_Callback callback) {
        Request request = new Request.Builder()
                .url(url)
                .header("apikey", API_KEY)
                .header("Authorization", "Bearer " + API_KEY)
                .build();

        executeRequest(request, callback);
    }

    public void post(@NonNull String url, @NonNull String jsonBody, @NonNull SBC_Callback callback) {
        RequestBody body = RequestBody.create(JSON, jsonBody);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .header("apikey", API_KEY)
                .header("Authorization", "Bearer " + API_KEY)
                .header("Content-Type", "application/json")
                .header("Prefer", "return=representation")
                .build();

        executeRequest(request, callback);
    }

    private void executeRequest(@NonNull Request request, @NonNull SBC_Callback callback) {
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                runOnMainThread(() -> callback.onFailure(e));
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    String responseBody = response.body().string();
                    runOnMainThread(() -> callback.onResponse(responseBody));
                } else {
                    String errorBody = response.body() != null ? response.body().string() : "Unknown error";
                    IOException exception = new IOException("HTTP error: " + response.code() + ", " + errorBody);
                    runOnMainThread(() -> callback.onFailure(exception));
                }
            }
        });
    }

    public void deleteBooking(String bookingId, SBC_Callback callback) {
        new Thread(() -> {
            try {
                OkHttpClient client = new OkHttpClient();

                Request request = new Request.Builder()
                        .url(DOMAIN_NAME + "/rest/v1/bookings?id=eq." + bookingId)
                        .header("apikey", API_KEY)
                        .header("Authorization", "Bearer " + API_KEY)
                        .delete()
                        .build();

                Response response = client.newCall(request).execute();

                if (response.isSuccessful()) {
                    callback.onResponse(response.body().string());
                } else {
                    callback.onFailure(new IOException("Ошибка сервера: " + response.code()));
                }
            } catch (IOException e) {
                callback.onFailure(e);
            }
        }).start();
    }

    private void runOnMainThread(Runnable runnable) {
        mainHandler.post(runnable);
    }
    public interface FavoriteCallback {
        void onResult(boolean isFavorite);
        void onError(Exception e);
    }



    public interface SimpleCallback {
        void onSuccess();
        void onError(Exception e);
    }
    public interface SBC_Callback {
        void onFailure(IOException e);
        void onResponse(String responseBody);
    }

    }
