package com.example.travenor;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.travenor.Models.Booking;
import com.example.travenor.Models.DataBinding;
import com.example.travenor.Models.HotelRoom;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class DashboardFragment extends Fragment implements ScheduleAdapter.OnBookingActionListener {

    private RecyclerView recyclerView;
    private ScheduleAdapter adapter;
    private List<Booking> bookingList = new ArrayList<>();
    private SwipeRefreshLayout swipeRefreshLayout;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_schedule, container, false);

        swipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setOnRefreshListener(this::loadBookings);

        recyclerView = view.findViewById(R.id.scheduleRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new ScheduleAdapter(bookingList, requireContext(), this);
        recyclerView.setAdapter(adapter);

        loadBookings();

        return view;
    }

    private void loadBookings() {
        if (!swipeRefreshLayout.isRefreshing()) {
            swipeRefreshLayout.setRefreshing(true);
        }

        String userId = DataBinding.getUuidUser();
        if (userId == null || userId.isEmpty()) {
            Toast.makeText(requireContext(), "Вы не авторизованы", Toast.LENGTH_SHORT).show();
            swipeRefreshLayout.setRefreshing(false);
            return;
        }

        SupabaseClient supabaseClient = new SupabaseClient();
        supabaseClient.fetchBookingsForUser(userId, new SupabaseClient.SBC_Callback() {
            @Override
            public void onFailure(IOException e) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    Toast.makeText(requireContext(), "Ошибка загрузки брони", Toast.LENGTH_SHORT).show();
                    swipeRefreshLayout.setRefreshing(false);
                });
            }

            @Override
            public void onResponse(String responseBody) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    try {
                        Gson gson = new Gson();
                        Type listType = new TypeToken<List<Booking>>(){}.getType();
                        List<Booking> bookings = gson.fromJson(responseBody, listType);

                        bookingList.clear();
                        if (bookings != null) {
                            bookingList.addAll(bookings);
                        }

                        adapter.notifyDataSetChanged();
                    } catch (Exception e) {
                        Toast.makeText(requireContext(), "Ошибка обработки данных", Toast.LENGTH_SHORT).show();
                    } finally {
                        swipeRefreshLayout.setRefreshing(false);
                    }
                });
            }
        });
    }

    @Override
    public void onEditBooking(Booking booking) {
        BookingFormActivity.startForEdit(requireContext(), booking);
    }

    @Override
    public void onDeleteBooking(String bookingId) {
        deleteBooking(bookingId);
    }

    private void deleteBooking(String bookingId) {
        SupabaseClient supabaseClient = new SupabaseClient();
        supabaseClient.deleteBooking(bookingId, new SupabaseClient.SBC_Callback() {
            @Override
            public void onFailure(IOException e) {
                new Handler(Looper.getMainLooper()).post(() ->
                        Toast.makeText(requireContext(), "Ошибка удаления брони", Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onResponse(String responseBody) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    adapter.removeBooking(bookingId);
                    Toast.makeText(requireContext(), "Бронь успешно удалена", Toast.LENGTH_SHORT).show();
                });
            }
        });
    }
}