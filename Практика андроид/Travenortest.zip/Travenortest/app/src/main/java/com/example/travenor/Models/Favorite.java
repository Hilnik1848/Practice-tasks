package com.example.travenor.Models;

public class Favorite {
    private String user_id;
    private String hotel_id;

    public String getUserId() { return user_id; }
    public String getHotelId() { return hotel_id; }
}