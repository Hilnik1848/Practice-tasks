package com.example.travenor;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.example.travenor.Models.Booking;
import com.example.travenor.Models.Hotel;
import com.example.travenor.Models.HotelRoom;
import java.util.List;

public class ScheduleAdapter extends RecyclerView.Adapter<ScheduleAdapter.ScheduleViewHolder> {

    private List<Booking> bookings;
    private Context context;
    private OnBookingActionListener actionListener;

    public interface OnBookingActionListener {
        void onEditBooking(Booking booking);
        void onDeleteBooking(String bookingId);
    }

    public ScheduleAdapter(List<Booking> bookings, Context context, OnBookingActionListener listener) {
        this.bookings = bookings;
        this.context = context;
        this.actionListener = listener;
    }

    @NonNull
    @Override
    public ScheduleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.schedule_item, parent, false);
        return new ScheduleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ScheduleViewHolder holder, int position) {
        Booking booking = bookings.get(position);
        Hotel hotel = booking.getHotel();
        HotelRoom hotelRoom = booking.getHotelRoom();

        if (hotel != null) {
            String imageUrl = hotel.getImageUrl();
            if (imageUrl != null && !imageUrl.startsWith("http")) {
                imageUrl = "https://mmbdesfnabtcbpjwcwde.supabase.co/storage/v1/object/public/hotel/" + imageUrl;
            }

            Glide.with(context)
                    .load(imageUrl)
                    .placeholder(R.drawable.img1)
                    .error(R.drawable.ic_launcher_foreground)
                    .into(holder.imageView);

            holder.destinationName.setText(hotel.getName());
            holder.location.setText(hotel.getAddres());

            String dateText = booking.getCheckInDate() + " - " + booking.getCheckOutDate();
            holder.date.setText(dateText);

            if (hotelRoom != null && hotelRoom.getRoom_type() != null) {
                holder.roomType.setText(hotelRoom.getRoom_type());
            } else {
                holder.roomType.setText("Тип номера не указан");
            }

            if (booking.getSumm() != null) {
                holder.price.setText(String.format("%,d ₽", booking.getSumm().intValue()));
            } else {
                holder.price.setText("Цена не указана");
            }
        }

        holder.btnEdit.setOnClickListener(v -> {
            if (actionListener != null) {
                actionListener.onEditBooking(booking);
            }
        });

        holder.btnDelete.setOnClickListener(v -> {
            if (actionListener != null) {
                actionListener.onDeleteBooking(booking.getId());
            }
        });
    }

    @Override
    public int getItemCount() {
        return bookings.size();
    }

    public void removeBooking(String bookingId) {
        for (int i = 0; i < bookings.size(); i++) {
            if (bookings.get(i).getId().equals(bookingId)) {
                bookings.remove(i);
                notifyItemRemoved(i);
                // Уведомляем об изменении позиций всех последующих элементов
                notifyItemRangeChanged(i, bookings.size() - i);
                break;
            }
        }
    }
    static class ScheduleViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView destinationName, location, date, price, roomType;
        ImageButton btnEdit, btnDelete;

        public ScheduleViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.scheduleItemImage);
            destinationName = itemView.findViewById(R.id.scheduleItemDestinationName);
            location = itemView.findViewById(R.id.scheduleItemLocation);
            date = itemView.findViewById(R.id.scheduleItemDate);
            price = itemView.findViewById(R.id.scheduleItemPrice);
            roomType = itemView.findViewById(R.id.scheduleItemRoomType);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}